package com.threlease.base.repositories.auth;

import com.threlease.base.entities.AuthPermissionGrantEntity;
import com.threlease.base.entities.AuthEntity;
import com.threlease.base.entities.AuthPermissionEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AuthPermissionGrantRepository extends JpaRepository<AuthPermissionGrantEntity, Long> {
    @Query("""
            SELECT g
            FROM AuthPermissionGrantEntity g
            JOIN FETCH g.permission p
            WHERE g.user = :user
              AND g.deletedAt IS NULL
              AND p.deletedAt IS NULL
            ORDER BY p.depth ASC, p.sortOrder ASC, p.id ASC
            """)
    List<AuthPermissionGrantEntity> findAllActiveByUser(@Param("user") AuthEntity user);

    @Query("""
            SELECT g
            FROM AuthPermissionGrantEntity g
            WHERE g.user = :user
              AND g.permission = :permission
              AND g.deletedAt IS NULL
            ORDER BY g.createdAt DESC, g.id DESC
            """)
    Page<AuthPermissionGrantEntity> findLatestActiveByUserAndPermission(@Param("user") AuthEntity user,
                                                                        @Param("permission") AuthPermissionEntity permission,
                                                                        Pageable pageable);
}
